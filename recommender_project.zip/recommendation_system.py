import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer

# Sample dataset
data = {
    'Movie': ['Inception', 'Titanic', 'Avengers', 'Interstellar', 'Matrix'],
    'Genre': ['Sci-Fi Action', 'Romance Drama', 'Action Superhero', 'Sci-Fi Drama', 'Sci-Fi Action']
}

df = pd.DataFrame(data)

# Vectorize genres
vectorizer = CountVectorizer()
genre_matrix = vectorizer.fit_transform(df['Genre'])

# Compute cosine similarity
cos_sim = cosine_similarity(genre_matrix)

def recommend(movie_title):
    if movie_title not in df['Movie'].values:
        return "Movie not found."
    idx = df[df['Movie'] == movie_title].index[0]
    sim_scores = list(enumerate(cos_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    recommended = [df.iloc[i[0]]['Movie'] for i in sim_scores[1:4]]
    return recommended

# Example usage
print("Recommendations for 'Inception':")
print(recommend('Inception'))
