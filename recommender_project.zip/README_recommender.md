# Simple Recommendation System

A content-based movie recommendation system using cosine similarity on genres.

## Features
- Uses text vectorization to compare movie genres
- Recommends similar movies based on genre
- Simple dataset and logic

## How to Run
```bash
python recommendation_system.py
```

Example output will show recommendations for "Inception".

## Requirements
- Python 3.x
- pandas
- scikit-learn
